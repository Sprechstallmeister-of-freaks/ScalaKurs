object Calculator {
  def add(a: Int, b: Int): Int = {
    return a + b
  }
}